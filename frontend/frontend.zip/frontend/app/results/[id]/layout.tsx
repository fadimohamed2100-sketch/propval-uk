import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Valuation Results — PropVal",
  description: "Your instant property valuation report.",
};

export default function ResultsLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
