"use client";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html>
      <body className="min-h-screen bg-surface flex items-center justify-center px-4 font-sans antialiased">
        <div className="text-center">
          <p className="font-mono text-xs uppercase tracking-widest text-red-400 mb-4">Error</p>
          <h1 className="font-display text-3xl text-ink mb-3">Something went wrong</h1>
          <p className="text-ink-muted text-sm mb-8 max-w-sm">
            {error.message ?? "An unexpected error occurred. Please try again."}
          </p>
          <div className="flex justify-center gap-3">
            <button
              onClick={reset}
              className="bg-ink text-stone-50 px-6 py-2.5 rounded-xl text-sm font-medium hover:bg-stone-800 transition-colors"
            >
              Try again
            </button>
            <a
              href="/"
              className="bg-stone-100 text-ink px-6 py-2.5 rounded-xl text-sm font-medium hover:bg-stone-200 transition-colors"
            >
              Go home
            </a>
          </div>
        </div>
      </body>
    </html>
  );
}
