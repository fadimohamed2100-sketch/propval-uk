import Link from "next/link";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-surface flex items-center justify-center px-4">
      <div className="text-center">
        <p className="font-mono text-xs uppercase tracking-widest text-gold-400 mb-4">404</p>
        <h1 className="font-display text-4xl text-ink mb-3">Page not found</h1>
        <p className="text-ink-muted mb-8">This valuation may have expired or the URL is incorrect.</p>
        <Link
          href="/"
          className="inline-flex items-center gap-2 bg-ink text-stone-50 px-6 py-3 rounded-xl
                     text-sm font-medium hover:bg-stone-800 transition-colors"
        >
          Back to search
        </Link>
      </div>
    </div>
  );
}
